// server.js
const express = require('express');
const fs = require('fs');
const fetch = require('node-fetch'); // если используете fetch, установите через npm i node-fetch

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Централизованный middleware ошибок (Задание 5)
app.use((err, req, res, next) => {
  console.error('Централизованный лог ошибок:', err.stack);
  res.status(500).send('Что-то пошло не так!');
});

// Задание 1: Генерация исключения
app.get('/error', (req, res) => {
  try {
    throw new Error('Тестовое исключение');
  } catch (err) {
    console.error('Ошибка /error:', err.message);
    res.status(500).send('Ошибка сервера');
  }
});

// Задание 2: Обработка неверного JSON
app.post('/parse-json', (req, res) => {
  try {
    const jsonStr = req.body.data;
    const obj = JSON.parse(jsonStr);
    res.json(obj);
  } catch (err) {
    console.error('Ошибка парсинга JSON:', err.message);
    res.status(400).send('Некорректный JSON');
  }
});

// Задание 3: Проверка входных данных
app.get('/user', (req, res) => {
  try {
    const name = req.query.name;
    if (!name) throw new Error('Имя обязательно');
    res.send(`Привет, ${name}!`);
  } catch (err) {
    console.error('Ошибка /user:', err.message);
    res.status(400).send(err.message);
  }
});

// Задание 4: асинхронный запрос через fetch
app.get('/fetch', async (req, res) => {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
    if (!response.ok) throw new Error(`Ответ сервиса: ${response.status}`);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error('Ошибка fetch:', err.message);
    res.status(503).send('Сервис недоступен');
  }
});

// Задание 6: логирование ошибкй в файл
app.get('/log-error', (req, res) => {
  try {
    throw new Error('Искусственная ошибка для логирования');
  } catch (err) {
    const logLine = `[${new Date().toISOString()}] Сообщение ошибки: ${err.message}\n`;
    fs.appendFile('errors.log', logLine, (err2) => {
      if (err2) console.error('Ошибка записи в файл лога:', err2);
    });
    res.status(500).send('Ошибка зафиксирована в логах');
  }
});

// Задание 7: обработка деления
app.get('/divide', (req, res) => {
  try {
    const a = parseFloat(req.query.a);
    const b = parseFloat(req.query.b);
    if (isNaN(a) || isNaN(b)) throw new Error('Некорректные числа');
    if (b === 0) throw new Error('Деление на ноль');
    res.send(`Результат: ${a / b}`);
  } catch (err) {
    if (err.message === 'Деление на ноль') {
      res.status(400).send(err.message);
    } else {
      res.status(400).send(err.message);
    }
  }
});

// Задание 8: проброс ошибки дальше
app.get('/data', (req, res, next) => {
  try {
    // допустим, ошибка
    throw new Error('Ошибка в /data');
  } catch (err) {
    next(err); // пробрасываем ошибку в централизованный обработчик
  }
});

// Задание 9: чтение файла
app.get('/read-file', (req, res) => {
  try {
    const data = fs.readFileSync('data.txt', 'utf-8');
    res.send(data);
  } catch (err) {
    if (err.code === 'ENOENT') {
      res.status(404).send('Файл не найден');
    } else {
      res.status(500).send('Ошибка чтения файла');
    }
  }
});

// Задание 10: комплекс
app.post('/process', (req, res) => {
  try {
    const { email } = req.body;
    // парсим json из тела
    if (!email) throw new Error('Поле email обязательно');
    fs.writeFileSync('data.json', JSON.stringify(req.body));
    res.send('Данные сохранены');
  } catch (err) {
    console.error('Ошибка обработки /process:', err.message);
    res.status(422).send(`Ошибка: ${err.message}`);
  }
});

// Запуск сервера
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});